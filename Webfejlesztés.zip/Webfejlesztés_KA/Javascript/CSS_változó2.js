function changeColor(){
    let color = document.getElementById("allcolor").value;
    document.body.style.backgroundColor = color; 
}

